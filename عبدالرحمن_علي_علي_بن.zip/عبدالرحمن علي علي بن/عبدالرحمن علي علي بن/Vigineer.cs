using System;
using System.Text;

namespace عبدالرحمن_علي_علي_بن
{
    public static class VigineerCipher
    {
        public static string Encrypt(string plainText, string key)
        {
            StringBuilder cipherText = new StringBuilder();
            key = key.ToUpper();
            int keyIndex = 0;

            foreach (char inputChar in plainText)
            {
                if (char.IsLetter(inputChar))
                {
                    char offset = char.IsUpper(inputChar) ? 'A' : 'a';
                    char keyChar = key[keyIndex % key.Length];
                    int shift = keyChar - 'A';

                    char encryptedChar = (char)(((inputChar + shift - offset) % 26) + offset);
                    cipherText.Append(encryptedChar);

                    keyIndex++;
                }
                else
                {
                    cipherText.Append(inputChar);
                }
            }
            return cipherText.ToString();
        }

        public static string Decrypt(string cipherText, string key)
        {
            StringBuilder plainText = new StringBuilder();
            key = key.ToUpper();
            int keyIndex = 0;

            foreach (char inputChar in cipherText)
            {
                if (char.IsLetter(inputChar))
                {
                    char offset = char.IsUpper(inputChar) ? 'A' : 'a';
                    char keyChar = key[keyIndex % key.Length];
                    int shift = keyChar - 'A';

                    char decryptedChar = (char)(((inputChar - shift - offset + 26) % 26) + offset);
                    plainText.Append(decryptedChar);

                    keyIndex++;
                }
                else
                {
                    plainText.Append(inputChar);
                }
            }
            return plainText.ToString();
        }
    }
}
