using System;
using System.Windows.Forms;

namespace عبدالرحمن_علي_علي_بن
{
    public partial class FormRSA : Form
    {
        private string publicKey;

        public FormRSA()
        {
            InitializeComponent();
            publicKey = RSACipher.GetPublicKey();
            txtPublicKey.Text = publicKey;
        }

        private void btnEncrypt_Click(object sender, EventArgs e)
        {
            try
            {
                string plainText = txtPlainText.Text;
                string targetPublicKey = txtPublicKey.Text; // Use the public key from the textbox
                txtCipherText.Text = RSACipher.Encrypt(plainText, targetPublicKey);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btnDecrypt_Click(object sender, EventArgs e)
        {
            try
            {
                string cipherText = txtCipherText.Text;
                txtPlainText.Text = RSACipher.Decrypt(cipherText);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
