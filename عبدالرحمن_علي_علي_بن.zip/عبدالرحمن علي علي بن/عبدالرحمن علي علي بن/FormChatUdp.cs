using System;
using System.Windows.Forms;

namespace عبدالرحمن_علي_علي_بن
{
    public partial class FormChatUdp : Form
    {
        private ChatUdp chatClient;

        public FormChatUdp()
        {
            InitializeComponent();
            this.FormClosing += FormChatUdp_FormClosing;
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            try
            {
                int localPort = int.Parse(txtLocalPort.Text);
                string remoteIp = txtRemoteIp.Text;
                int remotePort = int.Parse(txtRemotePort.Text);

                chatClient = new ChatUdp(localPort, remoteIp, remotePort);
                chatClient.MessageReceived += ChatClient_MessageReceived;
                MessageBox.Show("Connected to chat!");
                btnConnect.Enabled = false;
                btnSend.Enabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error connecting: " + ex.Message);
            }
        }

        private void ChatClient_MessageReceived(string message)
        {
            if (InvokeRequired)
            {
                Invoke(new Action<string>(ChatClient_MessageReceived), message);
                return;
            }
            txtChatHistory.AppendText("Received: " + message + Environment.NewLine);
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            try
            {
                if (chatClient != null)
                {
                    string message = txtMessage.Text;
                    chatClient.SendMessage(message);
                    txtChatHistory.AppendText("Sent: " + message + Environment.NewLine);
                    txtMessage.Clear();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error sending message: " + ex.Message);
            }
        }

        private void FormChatUdp_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (chatClient != null)
            {
                chatClient.Close();
            }
        }
    }
}
