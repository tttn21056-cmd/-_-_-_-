using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace عبدالرحمن_علي_علي_بن
{
    public static class AESCipher
    {
        private static byte[] GenerateRandomBytes(int length)
        {
            using (RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider())
            {
                byte[] randomBytes = new byte[length];
                rng.GetBytes(randomBytes);
                return randomBytes;
            }
        }

        public static string Encrypt(string plainText, string password)
        {
            byte[] salt = GenerateRandomBytes(16); // 16 bytes for salt
            byte[] iv = GenerateRandomBytes(16);   // 16 bytes for IV

            using (Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(password, salt, 10000, HashAlgorithmName.SHA256))
            {
                byte[] key = pdb.GetBytes(32); // 32 bytes for AES-256 key

                using (Aes aesAlg = Aes.Create())
                {
                    aesAlg.Key = key;
                    aesAlg.IV = iv;
                    aesAlg.Mode = CipherMode.CBC;
                    aesAlg.Padding = PaddingMode.PKCS7;

                    ICryptoTransform encryptor = aesAlg.CreateEncryptor(aesAlg.Key, aesAlg.IV);

                    using (MemoryStream msEncrypt = new MemoryStream())
                    {
                        using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                        {
                            using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
                            {
                                swEncrypt.Write(plainText);
                            }
                            byte[] encryptedBytes = msEncrypt.ToArray();
                            // Prepend IV and Salt to the encrypted data
                            byte[] result = new byte[salt.Length + iv.Length + encryptedBytes.Length];
                            Buffer.BlockCopy(salt, 0, result, 0, salt.Length);
                            Buffer.BlockCopy(iv, 0, result, salt.Length, iv.Length);
                            Buffer.BlockCopy(encryptedBytes, 0, result, salt.Length + iv.Length, encryptedBytes.Length);
                            return Convert.ToBase64String(result);
                        }
                    }
                }
            }
        }

        public static string Decrypt(string cipherText, string password)
        {
            byte[] fullCipher = Convert.FromBase64String(cipherText);

            // Extract Salt and IV
            byte[] salt = new byte[16];
            byte[] iv = new byte[16];
            byte[] encryptedBytes = new byte[fullCipher.Length - salt.Length - iv.Length];

            Buffer.BlockCopy(fullCipher, 0, salt, 0, salt.Length);
            Buffer.BlockCopy(fullCipher, salt.Length, iv, 0, iv.Length);
            Buffer.BlockCopy(fullCipher, salt.Length + iv.Length, encryptedBytes, 0, encryptedBytes.Length);

            using (Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(password, salt, 10000, HashAlgorithmName.SHA256))
            {
                byte[] key = pdb.GetBytes(32);

                using (Aes aesAlg = Aes.Create())
                {
                    aesAlg.Key = key;
                    aesAlg.IV = iv;
                    aesAlg.Mode = CipherMode.CBC;
                    aesAlg.Padding = PaddingMode.PKCS7;

                    ICryptoTransform decryptor = aesAlg.CreateDecryptor(aesAlg.Key, aesAlg.IV);

                    using (MemoryStream msDecrypt = new MemoryStream(encryptedBytes))
                    {
                        using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                        {
                            using (StreamReader srDecrypt = new StreamReader(csDecrypt))
                            {
                                return srDecrypt.ReadToEnd();
                            }
                        }
                    }
                }
            }
        }
    }
}
