using System;
using System.Windows.Forms;

namespace عبدالرحمن_علي_علي_بن
{
    public partial class FormSHA256 : Form
    {
        public FormSHA256()
        {
            InitializeComponent();
        }

        private void btnCalculateHash_Click(object sender, EventArgs e)
        {
            try
            {
                txtHash.Text = SHA256Hash.CalculateHash(txtInput.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
