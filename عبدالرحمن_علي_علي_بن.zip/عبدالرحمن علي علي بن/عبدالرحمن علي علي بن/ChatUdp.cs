using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace عبدالرحمن_علي_علي_بن
{
    public class ChatUdp
    {
        private UdpClient udpClient;
        private IPEndPoint remoteEndPoint;
        private Thread receiveThread;
        public event Action<string> MessageReceived;

        public ChatUdp(int localPort, string remoteIp, int remotePort)
        {
            udpClient = new UdpClient(localPort);
            remoteEndPoint = new IPEndPoint(IPAddress.Parse(remoteIp), remotePort);

            receiveThread = new Thread(ReceiveMessages);
            receiveThread.IsBackground = true;
            receiveThread.Start();
        }

        private void ReceiveMessages()
        {
            while (true)
            {
                try
                {
                    IPEndPoint senderEndPoint = new IPEndPoint(IPAddress.Any, 0);
                    byte[] receivedBytes = udpClient.Receive(ref senderEndPoint);
                    string encryptedMessage = Encoding.UTF8.GetString(receivedBytes);
                    // Assuming AES is used for chat encryption/decryption
                    // For simplicity, using a fixed password here. In a real app, this would be dynamic.
                    string decryptedMessage = AESCipher.Decrypt(encryptedMessage, "chatpassword"); 
                    MessageReceived?.Invoke(decryptedMessage);
                }
                catch (Exception ex)
                {
                    // Handle exceptions, e.g., if the socket is closed
                    Console.WriteLine("Receive error: " + ex.Message);
                    break;
                }
            }
        }

        public void SendMessage(string message)
        {
            // Assuming AES is used for chat encryption/decryption
            // For simplicity, using a fixed password here. In a real app, this would be dynamic.
            string encryptedMessage = AESCipher.Encrypt(message, "chatpassword");
            byte[] sendBytes = Encoding.UTF8.GetBytes(encryptedMessage);
            udpClient.Send(sendBytes, sendBytes.Length, remoteEndPoint);
        }

        public void Close()
        {
            udpClient.Close();
            receiveThread.Join(); // Wait for the thread to finish
        }
    }
}
