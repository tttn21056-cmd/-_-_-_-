namespace عبدالرحمن_علي_علي_بن
{
    partial class FormMain
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Button btnCaesar;
        private System.Windows.Forms.Button btnRot13;
        private System.Windows.Forms.Button btnAtbash;
        private System.Windows.Forms.Button btnVigenere;
        private System.Windows.Forms.Button btnAffine;
        private System.Windows.Forms.Button btnRSA;
        private System.Windows.Forms.Button btnAES;
        private System.Windows.Forms.Button btnMD5;
        private System.Windows.Forms.Button btnSHA256;
        private System.Windows.Forms.Button btnChat;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.btnCaesar = new System.Windows.Forms.Button();
            this.btnRot13 = new System.Windows.Forms.Button();
            this.btnAtbash = new System.Windows.Forms.Button();
            this.btnVigenere = new System.Windows.Forms.Button();
            this.btnAffine = new System.Windows.Forms.Button();
            this.btnRSA = new System.Windows.Forms.Button();
            this.btnAES = new System.Windows.Forms.Button();
            this.btnMD5 = new System.Windows.Forms.Button();
            this.btnSHA256 = new System.Windows.Forms.Button();
            this.btnChat = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnCaesar
            // 
            this.btnCaesar.Location = new System.Drawing.Point(50, 30);
            this.btnCaesar.Name = "btnCaesar";
            this.btnCaesar.Size = new System.Drawing.Size(150, 30);
            this.btnCaesar.TabIndex = 0;
            this.btnCaesar.Text = "Qaisar Cipher";
            this.btnCaesar.UseVisualStyleBackColor = true;
            this.btnCaesar.Click += new System.EventHandler(this.btnQaisar_Click);
            // 
            // btnRot13
            // 
            this.btnRot13.Location = new System.Drawing.Point(50, 70);
            this.btnRot13.Name = "btnRot13";
            this.btnRot13.Size = new System.Drawing.Size(150, 30);
            this.btnRot13.TabIndex = 1;
            this.btnRot13.Text = "ROT13 Cipher";
            this.btnRot13.UseVisualStyleBackColor = true;
            this.btnRot13.Click += new System.EventHandler(this.btnRot13_Click);
            // 
            // btnAtbash
            // 
            this.btnAtbash.Location = new System.Drawing.Point(50, 110);
            this.btnAtbash.Name = "btnAtbash";
            this.btnAtbash.Size = new System.Drawing.Size(150, 30);
            this.btnAtbash.TabIndex = 2;
            this.btnAtbash.Text = "Atbash Cipher";
            this.btnAtbash.UseVisualStyleBackColor = true;
            this.btnAtbash.Click += new System.EventHandler(this.btnAtbash_Click);
            // 
            // btnVigenere
            // 
            this.btnVigenere.Location = new System.Drawing.Point(50, 150);
            this.btnVigenere.Name = "btnVigenere";
            this.btnVigenere.Size = new System.Drawing.Size(150, 30);
            this.btnVigenere.TabIndex = 3;
            this.btnVigenere.Text = "Vigineer Cipher";
            this.btnVigenere.UseVisualStyleBackColor = true;
            this.btnVigenere.Click += new System.EventHandler(this.btnVigineer_Click);
            // 
            // btnAffine
            // 
            this.btnAffine.Location = new System.Drawing.Point(50, 190);
            this.btnAffine.Name = "btnAffine";
            this.btnAffine.Size = new System.Drawing.Size(150, 30);
            this.btnAffine.TabIndex = 4;
            this.btnAffine.Text = "Affine Cipher";
            this.btnAffine.UseVisualStyleBackColor = true;
            this.btnAffine.Click += new System.EventHandler(this.btnAffine_Click);
            // 
            // btnRSA
            // 
            this.btnRSA.Location = new System.Drawing.Point(220, 30);
            this.btnRSA.Name = "btnRSA";
            this.btnRSA.Size = new System.Drawing.Size(150, 30);
            this.btnRSA.TabIndex = 5;
            this.btnRSA.Text = "RSA Cipher";
            this.btnRSA.UseVisualStyleBackColor = true;
            this.btnRSA.Click += new System.EventHandler(this.btnRSA_Click);
            // 
            // btnAES
            // 
            this.btnAES.Location = new System.Drawing.Point(220, 70);
            this.btnAES.Name = "btnAES";
            this.btnAES.Size = new System.Drawing.Size(150, 30);
            this.btnAES.TabIndex = 6;
            this.btnAES.Text = "AES Cipher";
            this.btnAES.UseVisualStyleBackColor = true;
            this.btnAES.Click += new System.EventHandler(this.btnAES_Click);
            // 
            // btnMD5
            // 
            this.btnMD5.Location = new System.Drawing.Point(220, 110);
            this.btnMD5.Name = "btnMD5";
            this.btnMD5.Size = new System.Drawing.Size(150, 30);
            this.btnMD5.TabIndex = 7;
            this.btnMD5.Text = "MD5 Hash";
            this.btnMD5.UseVisualStyleBackColor = true;
            this.btnMD5.Click += new System.EventHandler(this.btnMD5_Click);
            // 
            // btnSHA256
            // 
            this.btnSHA256.Location = new System.Drawing.Point(220, 150);
            this.btnSHA256.Name = "btnSHA256";
            this.btnSHA256.Size = new System.Drawing.Size(150, 30);
            this.btnSHA256.TabIndex = 8;
            this.btnSHA256.Text = "SHA256 Hash";
            this.btnSHA256.UseVisualStyleBackColor = true;
            this.btnSHA256.Click += new System.EventHandler(this.btnSHA256_Click);
            // 
            // btnChat
            // 
            this.btnChat.Location = new System.Drawing.Point(135, 230);
            this.btnChat.Name = "btnChat";
            this.btnChat.Size = new System.Drawing.Size(150, 30);
            this.btnChat.TabIndex = 9;
            this.btnChat.Text = "Encrypted Chat";
            this.btnChat.UseVisualStyleBackColor = true;
            this.btnChat.Click += new System.EventHandler(this.btnChat_Click);
            // 
            // FormMain
            // 
            this.ClientSize = new System.Drawing.Size(420, 280);
            this.Controls.Add(this.btnChat);
            this.Controls.Add(this.btnSHA256);
            this.Controls.Add(this.btnMD5);
            this.Controls.Add(this.btnAES);
            this.Controls.Add(this.btnRSA);
            this.Controls.Add(this.btnAffine);
            this.Controls.Add(this.btnVigenere);
            this.Controls.Add(this.btnAtbash);
            this.Controls.Add(this.btnRot13);
            this.Controls.Add(this.btnCaesar);
            this.Name = "FormMain";
            this.Text = "Encryption Algorithms";
            this.ResumeLayout(false);
        }
    }
}
