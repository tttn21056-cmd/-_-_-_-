using System;
using System.Windows.Forms;

namespace عبدالرحمن_علي_علي_بن
{
    public partial class FormAtbash : Form
    {
        public FormAtbash()
        {
            InitializeComponent();
        }

        private void btnEncryptDecrypt_Click(object sender, EventArgs e)
        {
            try
            {
                txtOutput.Text = AtbashCipher.EncryptDecrypt(txtInput.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
