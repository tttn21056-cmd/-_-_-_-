using System;
using System.Windows.Forms;

namespace عبدالرحمن_علي_علي_بن
{
    public partial class FormAffine : Form
    {
        public FormAffine()
        {
            InitializeComponent();
        }

        private void btnEncrypt_Click(object sender, EventArgs e)
        {
            try
            {
                string plainText = txtPlainText.Text;
                int a = int.Parse(txtA.Text);
                int b = int.Parse(txtB.Text);
                txtCipherText.Text = AffineCipher.Encrypt(plainText, a, b);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btnDecrypt_Click(object sender, EventArgs e)
        {
            try
            {
                string cipherText = txtCipherText.Text;
                int a = int.Parse(txtA.Text);
                int b = int.Parse(txtB.Text);
                txtPlainText.Text = AffineCipher.Decrypt(cipherText, a, b);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
