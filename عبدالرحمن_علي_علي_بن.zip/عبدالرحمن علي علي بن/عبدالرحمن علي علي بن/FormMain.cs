using System;
using System.Windows.Forms;

namespace عبدالرحمن_علي_علي_بن
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
        }

        private void btnQaisar_Click(object sender, EventArgs e)
        {
            FormQaisar form = new FormQaisar();
            form.Show();
        }

        private void btnRot13_Click(object sender, EventArgs e)
        {
            FormRot13 form = new FormRot13();
            form.Show();
        }

        private void btnAtbash_Click(object sender, EventArgs e)
        {
            FormAtbash form = new FormAtbash();
            form.Show();
        }

        private void btnVigineer_Click(object sender, EventArgs e)
        {
            FormVigineer form = new FormVigineer();
            form.Show();
        }

        private void btnAffine_Click(object sender, EventArgs e)
        {
            FormAffine form = new FormAffine();
            form.Show();
        }

        private void btnRSA_Click(object sender, EventArgs e)
        {
            FormRSA form = new FormRSA();
            form.Show();
        }

        private void btnAES_Click(object sender, EventArgs e)
        {
            FormAES form = new FormAES();
            form.Show();
        }

        private void btnMD5_Click(object sender, EventArgs e)
        {
            FormMD5 form = new FormMD5();
            form.Show();
        }

        private void btnSHA256_Click(object sender, EventArgs e)
        {
            FormSHA256 form = new FormSHA256();
            form.Show();
        }

        private void btnChat_Click(object sender, EventArgs e)
        {
            FormChatUdp form = new FormChatUdp();
            form.Show();
        }
    }
}
