namespace عبدالرحمن_علي_علي_بن
{
    partial class FormSHA256
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.TextBox txtInput;
        private System.Windows.Forms.TextBox txtHash;
        private System.Windows.Forms.Button btnCalculateHash;
        private System.Windows.Forms.Label lblInput;
        private System.Windows.Forms.Label lblHash;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.txtInput = new System.Windows.Forms.TextBox();
            this.txtHash = new System.Windows.Forms.TextBox();
            this.btnCalculateHash = new System.Windows.Forms.Button();
            this.lblInput = new System.Windows.Forms.Label();
            this.lblHash = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtInput
            // 
            this.txtInput.Location = new System.Drawing.Point(120, 30);
            this.txtInput.Name = "txtInput";
            this.txtInput.Size = new System.Drawing.Size(200, 23);
            this.txtInput.TabIndex = 0;
            // 
            // txtHash
            // 
            this.txtHash.Location = new System.Drawing.Point(120, 70);
            this.txtHash.Name = "txtHash";
            this.txtHash.ReadOnly = true;
            this.txtHash.Size = new System.Drawing.Size(200, 23);
            this.txtHash.TabIndex = 1;
            // 
            // btnCalculateHash
            // 
            this.btnCalculateHash.Location = new System.Drawing.Point(120, 110);
            this.btnCalculateHash.Name = "btnCalculateHash";
            this.btnCalculateHash.Size = new System.Drawing.Size(100, 23);
            this.btnCalculateHash.TabIndex = 2;
            this.btnCalculateHash.Text = "Calculate SHA256";
            this.btnCalculateHash.UseVisualStyleBackColor = true;
            this.btnCalculateHash.Click += new System.EventHandler(this.btnCalculateHash_Click);
            // 
            // lblInput
            // 
            this.lblInput.AutoSize = true;
            this.lblInput.Location = new System.Drawing.Point(30, 33);
            this.lblInput.Name = "lblInput";
            this.lblInput.Text = "Input Text:";
            // 
            // lblHash
            // 
            this.lblHash.AutoSize = true;
            this.lblHash.Location = new System.Drawing.Point(30, 73);
            this.lblHash.Name = "lblHash";
            this.lblHash.Text = "SHA256 Hash:";
            // 
            // FormSHA256
            // 
            this.ClientSize = new System.Drawing.Size(384, 161);
            this.Controls.Add(this.lblHash);
            this.Controls.Add(this.lblInput);
            this.Controls.Add(this.btnCalculateHash);
            this.Controls.Add(this.txtHash);
            this.Controls.Add(this.txtInput);
            this.Name = "FormSHA256";
            this.Text = "SHA256 Hash";
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
