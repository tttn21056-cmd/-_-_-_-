namespace عبدالرحمن_علي_علي_بن
{
    partial class FormChatUdp
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.TextBox txtLocalPort;
        private System.Windows.Forms.TextBox txtRemoteIp;
        private System.Windows.Forms.TextBox txtRemotePort;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.TextBox txtChatHistory;
        private System.Windows.Forms.TextBox txtMessage;
        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.Label lblLocalPort;
        private System.Windows.Forms.Label lblRemoteIp;
        private System.Windows.Forms.Label lblRemotePort;
        private System.Windows.Forms.Label lblMessage;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.txtLocalPort = new System.Windows.Forms.TextBox();
            this.txtRemoteIp = new System.Windows.Forms.TextBox();
            this.txtRemotePort = new System.Windows.Forms.TextBox();
            this.btnConnect = new System.Windows.Forms.Button();
            this.txtChatHistory = new System.Windows.Forms.TextBox();
            this.txtMessage = new System.Windows.Forms.TextBox();
            this.btnSend = new System.Windows.Forms.Button();
            this.lblLocalPort = new System.Windows.Forms.Label();
            this.lblRemoteIp = new System.Windows.Forms.Label();
            this.lblRemotePort = new System.Windows.Forms.Label();
            this.lblMessage = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtLocalPort
            // 
            this.txtLocalPort.Location = new System.Drawing.Point(120, 30);
            this.txtLocalPort.Name = "txtLocalPort";
            this.txtLocalPort.Size = new System.Drawing.Size(100, 23);
            this.txtLocalPort.TabIndex = 0;
            this.txtLocalPort.Text = "12345";
            // 
            // txtRemoteIp
            // 
            this.txtRemoteIp.Location = new System.Drawing.Point(120, 70);
            this.txtRemoteIp.Name = "txtRemoteIp";
            this.txtRemoteIp.Size = new System.Drawing.Size(150, 23);
            this.txtRemoteIp.TabIndex = 1;
            this.txtRemoteIp.Text = "127.0.0.1";
            // 
            // txtRemotePort
            // 
            this.txtRemotePort.Location = new System.Drawing.Point(120, 110);
            this.txtRemotePort.Name = "txtRemotePort";
            this.txtRemotePort.Size = new System.Drawing.Size(100, 23);
            this.txtRemotePort.TabIndex = 2;
            this.txtRemotePort.Text = "12346";
            // 
            // btnConnect
            // 
            this.btnConnect.Location = new System.Drawing.Point(120, 150);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(75, 23);
            this.btnConnect.TabIndex = 3;
            this.btnConnect.Text = "Connect";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // txtChatHistory
            // 
            this.txtChatHistory.Location = new System.Drawing.Point(30, 190);
            this.txtChatHistory.Multiline = true;
            this.txtChatHistory.Name = "txtChatHistory";
            this.txtChatHistory.ReadOnly = true;
            this.txtChatHistory.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtChatHistory.Size = new System.Drawing.Size(350, 150);
            this.txtChatHistory.TabIndex = 4;
            // 
            // txtMessage
            // 
            this.txtMessage.Location = new System.Drawing.Point(30, 360);
            this.txtMessage.Name = "txtMessage";
            this.txtMessage.Size = new System.Drawing.Size(270, 23);
            this.txtMessage.TabIndex = 5;
            // 
            // btnSend
            // 
            this.btnSend.Enabled = false;
            this.btnSend.Location = new System.Drawing.Point(305, 360);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(75, 23);
            this.btnSend.TabIndex = 6;
            this.btnSend.Text = "Send";
            this.btnSend.UseVisualStyleBackColor = true;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // lblLocalPort
            // 
            this.lblLocalPort.AutoSize = true;
            this.lblLocalPort.Location = new System.Drawing.Point(30, 33);
            this.lblLocalPort.Name = "lblLocalPort";
            this.lblLocalPort.Text = "Local Port:";
            // 
            // lblRemoteIp
            // 
            this.lblRemoteIp.AutoSize = true;
            this.lblRemoteIp.Location = new System.Drawing.Point(30, 73);
            this.lblRemoteIp.Name = "lblRemoteIp";
            this.lblRemoteIp.Text = "Remote IP:";
            // 
            // lblRemotePort
            // 
            this.lblRemotePort.AutoSize = true;
            this.lblRemotePort.Location = new System.Drawing.Point(30, 113);
            this.lblRemotePort.Name = "lblRemotePort";
            this.lblRemotePort.Text = "Remote Port:";
            // 
            // lblMessage
            // 
            this.lblMessage.AutoSize = true;
            this.lblMessage.Location = new System.Drawing.Point(30, 344);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Text = "Message:";
            // 
            // FormChatUdp
            // 
            this.ClientSize = new System.Drawing.Size(400, 400);
            this.Controls.Add(this.lblMessage);
            this.Controls.Add(this.lblRemotePort);
            this.Controls.Add(this.lblRemoteIp);
            this.Controls.Add(this.lblLocalPort);
            this.Controls.Add(this.btnSend);
            this.Controls.Add(this.txtMessage);
            this.Controls.Add(this.txtChatHistory);
            this.Controls.Add(this.btnConnect);
            this.Controls.Add(this.txtRemotePort);
            this.Controls.Add(this.txtRemoteIp);
            this.Controls.Add(this.txtLocalPort);
            this.Name = "FormChatUdp";
            this.Text = "Encrypted Chat";
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
