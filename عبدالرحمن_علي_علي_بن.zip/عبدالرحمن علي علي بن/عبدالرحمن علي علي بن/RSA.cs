using System;
using System.Security.Cryptography;
using System.Text;

namespace عبدالرحمن_علي_علي_بن
{
    public static class RSACipher
    {
        private static RSACryptoServiceProvider rsa = new RSACryptoServiceProvider(2048);
        private static UnicodeEncoding ByteConverter = new UnicodeEncoding();

        public static string GetPublicKey()
        {
            return rsa.ToXmlString(false);
        }

        public static string Encrypt(string plainText, string publicKey)
        {
            byte[] dataToEncrypt = ByteConverter.GetBytes(plainText);
            byte[] encryptedData;
            using (RSACryptoServiceProvider rsaPublic = new RSACryptoServiceProvider())
            {
                rsaPublic.FromXmlString(publicKey);
                encryptedData = rsaPublic.Encrypt(dataToEncrypt, false);
            }
            return Convert.ToBase64String(encryptedData);
        }

        public static string Decrypt(string cipherText)
        {
            byte[] dataToDecrypt = Convert.FromBase64String(cipherText);
            byte[] decryptedData = rsa.Decrypt(dataToDecrypt, false);
            return ByteConverter.GetString(decryptedData);
        }
    }
}
