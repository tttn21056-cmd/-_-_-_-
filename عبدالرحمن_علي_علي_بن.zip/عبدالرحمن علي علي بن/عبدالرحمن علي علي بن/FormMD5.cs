using System;
using System.Windows.Forms;

namespace عبدالرحمن_علي_علي_بن
{
    public partial class FormMD5 : Form
    {
        public FormMD5()
        {
            InitializeComponent();
        }

        private void btnCalculateHash_Click(object sender, EventArgs e)
        {
            try
            {
                txtHash.Text = MD5Hash.CalculateHash(txtInput.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
