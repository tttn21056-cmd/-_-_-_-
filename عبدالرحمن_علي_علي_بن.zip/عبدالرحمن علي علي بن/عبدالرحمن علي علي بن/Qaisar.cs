using System;
using System.Text;

namespace عبدالرحمن_علي_علي_بن
{
    public static class QaisarCipher
    {
        public static string Encrypt(string plainText, int shift)
        {
            StringBuilder result = new StringBuilder();
            foreach (char c in plainText)
            {
                if (char.IsLetter(c))
                {
                    char offset = char.IsUpper(c) ? 'A' : 'a';
                    result.Append((char)(((c + shift - offset) % 26) + offset));
                }
                else
                {
                    result.Append(c);
                }
            }
            return result.ToString();
        }

        public static string Decrypt(string cipherText, int shift)
        {
            return Encrypt(cipherText, 26 - shift);
        }
    }
}
