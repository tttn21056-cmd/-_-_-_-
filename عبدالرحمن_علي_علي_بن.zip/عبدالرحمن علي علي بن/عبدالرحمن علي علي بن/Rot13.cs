using System;
using System.Text;

namespace عبدالرحمن_علي_علي_بن
{
    public static class Rot13Cipher
    {
        public static string EncryptDecrypt(string text)
        {
            StringBuilder result = new StringBuilder();
            foreach (char c in text)
            {
                if (char.IsLetter(c))
                {
                    char offset = char.IsUpper(c) ? 'A' : 'a';
                    result.Append((char)(((c - offset + 13) % 26) + offset));
                }
                else
                {
                    result.Append(c);
                }
            }
            return result.ToString();
        }
    }
}
