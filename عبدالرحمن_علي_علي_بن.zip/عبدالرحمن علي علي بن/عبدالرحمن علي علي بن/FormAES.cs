using System;
using System.Windows.Forms;

namespace عبدالرحمن_علي_علي_بن
{
    public partial class FormAES : Form
    {
        public FormAES()
        {
            InitializeComponent();
        }

        private void btnEncrypt_Click(object sender, EventArgs e)
        {
            try
            {
                string plainText = txtPlainText.Text;
                string password = txtPassword.Text;
                txtCipherText.Text = AESCipher.Encrypt(plainText, password);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btnDecrypt_Click(object sender, EventArgs e)
        {
            try
            {
                string cipherText = txtCipherText.Text;
                string password = txtPassword.Text;
                txtPlainText.Text = AESCipher.Decrypt(cipherText, password);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
