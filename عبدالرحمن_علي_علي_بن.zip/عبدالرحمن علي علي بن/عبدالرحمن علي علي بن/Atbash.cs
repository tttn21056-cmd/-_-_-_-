using System.Text;

namespace عبدالرحمن_علي_علي_بن
{
    public static class AtbashCipher
    {
        public static string EncryptDecrypt(string text)
        {
            StringBuilder result = new StringBuilder();
            foreach (char c in text)
            {
                if (char.IsLetter(c))
                {
                    if (char.IsUpper(c))
                    {
                        result.Append((char)('Z' - (c - 'A')));
                    }
                    else
                    {
                        result.Append((char)('z' - (c - 'a')));
                    }
                }
                else
                {
                    result.Append(c);
                }
            }
            return result.ToString();
        }
    }
}
