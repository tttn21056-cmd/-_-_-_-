using System;
using System.Windows.Forms;

namespace عبدالرحمن_علي_علي_بن
{
    public partial class FormQaisar : Form
    {
        public FormCaesar()
        {
            InitializeComponent();
        }

        private void btnEncrypt_Click(object sender, EventArgs e)
        {
            try
            {
                string plainText = txtPlainText.Text;
                int shift = int.Parse(txtShift.Text);
                txtCipherText.Text = QaisarCipher.Encrypt(plainText, shift);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btnDecrypt_Click(object sender, EventArgs e)
        {
            try
            {
                string cipherText = txtCipherText.Text;
                int shift = int.Parse(txtShift.Text);
                txtPlainText.Text = QaisarCipher.Decrypt(cipherText, shift);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
