using System;
using System.Text;

namespace عبدالرحمن_علي_علي_بن
{
    public static class AffineCipher
    {
        // Function to find gcd of a and b
        static int gcd(int a, int h)
        {
            int temp;
            while (true)
            {
                temp = a % h;
                if (temp == 0)
                    return h;
                a = h;
                h = temp;
            }
        }

        public static string Encrypt(string plainText, int a, int b)
        {
            StringBuilder result = new StringBuilder();
            foreach (char c in plainText)
            {
                if (char.IsLetter(c))
                {
                    char offset = char.IsUpper(c) ? 'A' : 'a';
                    result.Append((char)(((a * (c - offset) + b) % 26) + offset));
                }
                else
                {
                    result.Append(c);
                }
            }
            return result.ToString();
        }

        public static string Decrypt(string cipherText, int a, int b)
        {
            StringBuilder result = new StringBuilder();
            int a_inv = 0;
            int flag = 0;

            // Find a^-1 (the multiplicative inverse of a in the group of integers modulo m)
            for (int i = 0; i < 26; i++)
            {
                flag = (a * i) % 26;
                if (flag == 1)
                {
                    a_inv = i;
                }
            }

            foreach (char c in cipherText)
            {
                if (char.IsLetter(c))
                {
                    char offset = char.IsUpper(c) ? 'A' : 'a';
                    result.Append((char)(((a_inv * ((c - offset - b + 26)) % 26)) + offset));
                }
                else
                {
                    result.Append(c);
                }
            }
            return result.ToString();
        }
    }
}
