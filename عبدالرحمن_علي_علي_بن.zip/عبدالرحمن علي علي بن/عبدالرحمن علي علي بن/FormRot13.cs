using System;
using System.Windows.Forms;

namespace عبدالرحمن_علي_علي_بن
{
    public partial class FormRot13 : Form
    {
        public FormRot13()
        {
            InitializeComponent();
        }

        private void btnEncryptDecrypt_Click(object sender, EventArgs e)
        {
            try
            {
                txtOutput.Text = Rot13Cipher.EncryptDecrypt(txtInput.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
